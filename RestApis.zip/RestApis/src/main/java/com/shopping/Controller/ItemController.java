package com.shopping.Controller;

	import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.Entity.Item;
import com.shopping.Service.ItemService;

import jakarta.validation.Valid;

	@RestController
	@RequestMapping("/items")
	public class ItemController {

	    private final ItemService service;

	    public ItemController(ItemService service) {
	        this.service = service;
	    }

	    // Add new item
	    @PostMapping
	    public ResponseEntity<Item> addItem(@Valid @RequestBody Item item) {
	        Item created = service.addItem(item);
	        return new ResponseEntity<>(created, HttpStatus.CREATED);
	    }

	    // Get item by ID
	    @GetMapping("/{id}")
	    public ResponseEntity<Item> getItem(@PathVariable int id) {
	        return service.getItemById(id)
	                .map(ResponseEntity::ok)
	                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND));
	    }

	    // Get all items
	    @GetMapping
	    public List<Item> getAllItems() {
	        return service.getAllItems();
	    }
	}

