package com.shopping.ServiceImpl;


	import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.shopping.Entity.Item;
import com.shopping.Service.ItemService;

	@Service
	public class ItemServiceImpl implements ItemService {

	    private List<Item> items = new ArrayList<>();
	    private int nextId = 1;

	    @Override
	    public Item addItem(Item item) {
	        item.setId(nextId++);
	        items.add(item);
	        return item;
	    }

	    @Override
	    public Optional<Item> getItemById(int id) {
	        return items.stream()
	                .filter(i -> i.getId() == id)
	                .findFirst();
	    }

	    @Override
	    public List<Item> getAllItems() {
	        return items;
	    }
	}

	

