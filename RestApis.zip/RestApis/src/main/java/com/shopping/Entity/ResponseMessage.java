package com.shopping.Entity;

import java. util.List;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
@Data
//@AllArgsConstructor
//@ NoArgsConstructor
@RequiredArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ResponseMessage {

private Integer statuscode;
private String status;
private String Message;
private Object data;
private List<?>list;

public ResponseMessage(Integer statuscode, String status, String message, Object data, List<?> list) {
	super();
	this.statuscode = statuscode;
	this.status = status;
	this.Message = message;
	this.data = data;
	this.list = list;
}

public ResponseMessage(Integer statuscode, String status, String message) {
	super();
	this.statuscode = statuscode;
	this.status = status;
	this.Message = message;
}

public ResponseMessage(Integer statuscode, String status, String message, Object data) {
	super();
	this.statuscode = statuscode;
	this.status = status;
	this.Message = message;
	this.data = data;
}
}
